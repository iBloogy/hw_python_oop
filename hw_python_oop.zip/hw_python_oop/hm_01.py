import datetime as dt
        
class Record:
    def __init__(self, amount, comment, date=None):
        self.amount = amount
        self.comment = comment
        if date == None:
            self.date = dt.date.today()
        else:
            moment = dt.datetime.strptime(date, '%d.%m.%Y')
            self.date = moment.date()


class Calculator:
    def __init__(self, limit):
        self.limit = limit
        self.records = []
    def __str__(self):
        return self.records

    def add_record(self, records):
        self.records.append(records)

    def get_today_stats(self):
        today_stats = 0
        today = dt.date.today()
        for rec in self.records: 
            if rec.date == today:
                today_stats += rec.amount
        return today_stats

    def get_week_stats(self):
        week_stats = 0
        today = dt.date.today()
        start_week = today - dt.timedelta(days=6)
        for rec in self.records:
            if today >= rec.date >= start_week:
                week_stats += rec.amount
        return week_stats

    def today_spent(self):
        return self.limit - self.get_today_stats()


class CashCalculator(Calculator):
    USD_RATE = 74.05
    EURO_RATE = 87.07
    RUB_RATE = 1

    def get_today_cash_remained(self, currensy):
        self.currensy = currensy
        currensy_rate = {'rub': (self.RUB_RATE, 'руб.'),
                         'eur': (self.EURO_RATE, 'EUR'),
                         'usd': (self.USD_RATE, 'USD')
                         }
        currensy_curse, currensy_name = currensy_rate[currensy]
        total_remain = self.today_spent()/currensy_curse
        if self.today_spent() > 0:
            return f'На сегодня осталось {total_remain:.2f} {currensy_name}'
        elif self.today_spent() == 0:
            return f'На сегодня денег не осталось :('
        elif self.today_spent() < 0:
            return f'На сегодня денег не осталось. Твой долг: {total_remain:.2f} {currensy_name}'

class CaloriesCalculator(Calculator):
    def get_today_calories_remained(self):
        today_spent = self.today_spent()
        if today_spent > 0:
            return f'Сегодня можно cъесть что-нибудь ещё, но с общей калорийностью не более {today_spent} кКал'
        else:
            return f'Хватит есть!'



if __name__ == '__main__':        
# создадим калькулятор денег с дневным лимитом 1000
    cash_calculator = CashCalculator(1000)
# дата в параметрах не указана, 
# так что по умолчанию к записи должна автоматически добавиться сегодняшняя дата
    cash_calculator.add_record(Record(amount=1145, comment='кофе')) 
# и к этой записи тоже дата должна добавиться автоматически
    cash_calculator.add_record(Record(amount=300, comment='Серёге за обед'))
# а тут пользователь указал дату, сохраняем её
    cash_calculator.add_record(Record(amount=3000, comment='бар в Танин др', date='31.12.2008'))      
    print(cash_calculator.get_today_cash_remained('usd'))
# создадим калькулятор калорий с дневным лимитом 4000
    calories_calculator = CaloriesCalculator(5000)
# дата в параметрах не указана, 
# так что по умолчанию к записи должна автоматически добавиться сегодняшняя дата
    calories_calculator.add_record(Record(amount=600, comment='бигмак')) 
# и к этой записи тоже дата должна добавиться автоматически
    calories_calculator.add_record(Record(amount=500, comment='пюре с куриной грудкой'))
    print(calories_calculator.get_today_calories_remained())