import datetime as dt
        
class Record:
    def __init__(self, amount, comment, date=None):
        self.amount = amount
        self.comment = comment
        if date == None:
            self.date = dt.date.today()
        else:
            moment = dt.datetime.strptime(date, '%d.%m.%Y')
            self.date = moment.date()


class Calculator:
    def __init__(self, limit):
        self.limit = limit
        self.records = []

    def add_record(self, records):
        self.records.append(records)

    def today_stats(self):
        today = dt.date.today()
        return sum(rec.amount for rec in self.records if rec.date == today)

    def get_today_stats(self):
        return self.today_stats()

    def get_week_stats(self):
        week_stats = 0
        today = dt.date.today()
        start_week = today - dt.timedelta(days=6)
        for rec in self.records:
            if today >= rec.date >= start_week:
                week_stats += rec.amount
        return week_stats

    def get_today_spent(self):
        return self.limit - self.get_today_stats()

class CashCalculator(Calculator):
    EURO_RATE = 70.00
    USD_RATE = 60.00
    RUB_RATE = 1
    dict_rate = {'eur': (EURO_RATE, 'Euro'),
                 'usd': (USD_RATE, 'USD'),
                 'rub': (RUB_RATE, 'руб')}

    def get_today_cash_remained(self, currensy):
        today_spent = self.get_today_spent()
        currensy_rate, currensy_name = self.dict_rate[currensy]
        total_remain = abs(today_spent/currensy_rate)
        if today_spent > 0:
            return f'На сегодня осталось {total_remain:.2f} {currensy_name}'
        elif today_spent == 0:
            return 'Денег нет, держись'
        elif today_spent < 0:
            return f'Денег нет, держись: твой долг - {total_remain:.2f} {currensy_name}'

class CaloriesCalculator(Calculator):
    def get_calories_remained(self):
        today_spent = self.get_today_spent()
        if today_spent > 0:
            return ('Сегодня можно съесть что-нибудь ещё, '
                    f'но с общей калорийностью не более {today_spent} кКал')
        return 'Хватит есть!'


if __name__ == '__main__':        
# создадим калькулятор денег с дневным лимитом 1000
    cash_calculator = CashCalculator(1000)
# дата в параметрах не указана, 
# так что по умолчанию к записи должна автоматически добавиться сегодняшняя дата
    cash_calculator.add_record(Record(amount=1145, comment='кофе')) 
# и к этой записи тоже дата должна добавиться автоматически
    cash_calculator.add_record(Record(amount=300, comment='Серёге за обед'))
# а тут пользователь указал дату, сохраняем её
    cash_calculator.add_record(Record(amount=3000, comment='бар в Танин др', date='31.12.2020'))      
    print(cash_calculator.get_today_cash_remained('usd'))
# создадим калькулятор калорий с дневным лимитом 4000
    calories_calculator = CaloriesCalculator(4000)
# дата в параметрах не указана, 
# так что по умолчанию к записи должна автоматически добавиться сегодняшняя дата
    calories_calculator.add_record(Record(amount=600, comment='бигмак')) 
# и к этой записи тоже дата должна добавиться автоматически
    calories_calculator.add_record(Record(amount=500, comment='пюре с куриной грудкой'))
    print(calories_calculator.get_calories_remained())